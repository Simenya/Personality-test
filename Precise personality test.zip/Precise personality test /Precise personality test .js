
function OnStart()
{
  //cover layout
  
cover = app.CreateLayout( "Linear", "VCenter,FillXY" );
  
	cover.SetBackground("Img/cd1.jpg" );
	cover.SetVisibility( "Hide" );
	
	coverH = app.CreateLayout( "Linear", "Horizontal" );
	cover.AddChild(coverH);
	about  = app.CreateButton( "About",0.3, 0.06 );
	about .SetMargins(0,0,5,0,"px");
  about .SetOnTouch( about_OnTouch );	
  coverH.AddChild( about  );
  
  start = app.CreateButton( "Start",0.3, 0.06 );
  start .SetOnTouch( start_OnTouch );	
  coverH.AddChild( start );

  // main layout
	main= app.CreateLayout( "Linear", "VCentr,FillXY" );
	main.SetBackground( "" );
	
	img1 = app.CreateImage("/Sys/Img/Droid1.png",0.09);
	
	
	main.AddChild(img1);
	
	// new text
	var text = "<h2><font color='#ff0322'>The Personality Test </font></h2><br><br><p><b>Here are 3 questions  that will suprise you.</p><p>Remember the Mind is a Parachute and work's best if it is open.<br>Be Honest with yourself</p>"
	txt1 = app.CreateText( text,0.9,-1,"Html,Link" );
	txt1.SetTextSize( 19 );
	txt1.SetTextColor( "#22ff00" );
	img1.SetMargins(0,0.09,0,0.);
// 	txt1.SetMargins( 0.01, 0.01, 0.01, 0.01 );
	main.AddChild( txt1 );


// Horizontal layer
layHoriz = app.CreateLayout( "Linear", "Horizontal" );
 main.AddChild( layHoriz );
 
 nxt = app.CreateButton( "Start" ,0.3, 0.06 );
	 nxt.SetOnTouch( nxt_OnTouch );
	 layHoriz.AddChild( nxt );
	
	 nxt = app.CreateButton( "Proceed" );
	 nxt.SetOnTouch( nxt);
	//2nd layout
	ly = app.CreateLayout( "Linear", "VCenter,FillXY" );
	ly.SetBackground("/Sys/Img/BlueBack.jpg" );
	ly.SetVisibility( "Hide" );

 var text = "<p>Put the following 5 animals in the order of your preference:</p><p><i><font color='#ff2211'>Cow,Tiger,Sheep,Horse,Pig</i></font></p>"
	txt1 = app.CreateText( text,0.9,-1,"Html,Link" );
	txt1.SetTextSize( 18 );
	txt1.SetTextColor( "#22ff22" );
	txt1.SetMargins( 0.01, 0.01, 0.01, 0.01 );
	ly.AddChild( txt1 );
	
	txtarea = app.CreateTextEdit( "",0.8 );
	txtarea.SetTextColor( "#ffff22" );
	ly.AddChild( txtarea );
	
	bck = app.CreateButton( "next",0.3, 0.06 );
  bck.SetOnTouch( bck_OnTouch );	
  ly.AddChild( bck );

//3rd Layout
ly1 = app.CreateLayout( "Linear", "VCenter,FillXY" );
	ly1.SetBackground("Img/wl1.jpg" );
	ly1.SetVisibility( "Hide" );


	var text = "<p>Write one word that describes each one of the following:<br><font color='#ff2211'><i></i></font></p>"
	txt2 = app.CreateText( text,0.9,-1,"Html,Link" );

	txt2.SetTextSize( 18 );
	txt2.SetTextColor( "#22ff22" );
	ly1.AddChild( txt2 );
	
			l2 = app.CreateLayout( "linear", "Horizontal" );	
		ly1.AddChild( l2 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Dog:    " );
	//txt.SetTextSize( 32 );
	txt.SetTextColor('#ffff00');
	l2.AddChild( txt );
	
	t2 = app.CreateTextEdit( "",0.5 );
	l2.AddChild( t2 );
	
			l3 = app.CreateLayout( "linear", "Horizontal" );	
		ly1.AddChild( l3 );

	//Create a text label and add it to layout.
	txt1 = app.CreateText( "Cat:   " );
	txt1.SetTextColor('#ffff00');
	//txt.SetTextSize( 32 );
	l3.AddChild( txt1 );
	
	t3 = app.CreateTextEdit( "",0.5 );
	l3.AddChild( t3 );
	
		l4 = app.CreateLayout( "linear", "Horizontal" );	
		ly1.AddChild( l4 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Rat:    " );
	txt.SetTextColor('#ffff00');
	//txt.SetTextSize( 32 );
	l4.AddChild( txt );
	
	t4 = app.CreateTextEdit( "",0.5 );
	l4.AddChild( t4 );
	
	// 4th edit box
	l5 = app.CreateLayout( "linear", "Horizontal" );	
		ly1.AddChild( l5 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Coffee:  " );
	txt.SetTextColor('#ffff00');
	//txt.SetTextSize( 32 );
	l5.AddChild( txt );
	
	t5 = app.CreateTextEdit( "",0.5 );
	l5.AddChild( t5 );
	
	
	//5th
	l6 = app.CreateLayout( "linear", "Horizontal" );	
		ly1.AddChild( l6 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Sea:		" );
	txt.SetTextColor('#ffff00');
	//txt.SetTextSize( 32 );
	l6.AddChild( txt );
	
	t6 = app.CreateTextEdit( "",0.5 );
	l6.AddChild( t6 );
	
	bck1 = app.CreateButton( "proceed",0.3, 0.06 );
  bck1.SetOnTouch( bck1_OnTouch );	
  ly1.AddChild( bck1 );
  
  //4th Layout
ly2 = app.CreateLayout( "Linear", "VCenter,FillXY" );
	ly2.SetBackground("Img/wl2.jpg" );
	ly2.SetVisibility( "Hide" );


	var text = "<p><b>Think of someone, who also knows you and is important to you, which you can relate them to the following colors. Do not repeat your answer twice. Name just one person for each color:</p>"
	txt2 =  app.CreateText( text,0.9,-1,"Html,Link" );
	txt2.SetTextSize( 18 );
	txt2.SetTextColor( "#22ff22" );
	ly2.AddChild( txt2 );
	
			l2 = app.CreateLayout( "linear", "Horizontal" );	
		ly2.AddChild( l2 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Yellow:  " );
	//txt.SetTextSize( 32 );
	l2.AddChild( txt );
	
	tt2 = app.CreateTextEdit( "",0.5 );
	l2.AddChild( tt2 );
	
			l3 = app.CreateLayout( "linear", "Horizontal" );	
		ly2.AddChild( l3 );

	//Create a text label and add it to layout.
	txt1 = app.CreateText( "Orange:  " );
	//txt.SetTextSize( 32 );
	l3.AddChild( txt1 );
	
	tt3 = app.CreateTextEdit( "",0.5 );
	l3.AddChild( tt3 );
	
		l4 = app.CreateLayout( "linear", "Horizontal" );	
		ly2.AddChild( l4 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Red:    " );
	//txt.SetTextSize( 32 );
	l4.AddChild( txt );
	
	tt4 = app.CreateTextEdit( "",0.5 );
	l4.AddChild( tt4 );
	
	// 4th edit box
	l5 = app.CreateLayout( "linear", "Horizontal" );	
		ly2.AddChild( l5 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "White:  " );
	//txt.SetTextSize( 32 );
	l5.AddChild( txt );
	
	tt5 = app.CreateTextEdit( "",0.5 );
	l5.AddChild( tt5 );
	
	
	//5th edit box
	l6 = app.CreateLayout( "linear", "Horizontal" );	
		ly2.AddChild( l6 );

	//Create a text label and add it to layout.
	txt = app.CreateText( "Green:  " )
	//txt.SetTextSize( 32 );
	l6.AddChild( txt );
	
	tt6 = app.CreateTextEdit( "",0.5 );
	l6.AddChild( tt6 );
	
	
	bck2 = app.CreateButton( "Results",0.3, 0.06 );
  bck2.SetOnTouch( bck2_OnTouch );	
  ly2.AddChild( bck2 );

  

//5th layout
	ly3 = app.CreateLayout( "Linear", "VCenter,FillXY" );
  
	ly3.SetBackground("/Sys/Img/BlueBack.jpg" );
	ly3.SetVisibility( "Hide" );
	
	ly3H = app.CreateLayout( "Linear", "Horizontal" );
	ly3.AddChild(ly3H);
	rev1 = app.CreateButton( "reveal 1",0.3, 0.06 );
	rev1.SetMargins(0,0,5,0,"px");
  rev1.SetOnTouch( rev1_OnTouch );	
  ly3H.AddChild( rev1 );
  
  nxt1 = app.CreateButton( "next",0.3, 0.06 );
  nxt1.SetOnTouch( nxt1_OnTouch );	
  ly3H.AddChild(nxt1);


// 6th Layout
ly4 = app.CreateLayout( "Linear", "VCenter,FillXY" );
  
	ly4.SetBackground("/Sys/Img/GreenBack.jpg" );
	ly4.SetVisibility( "Hide" );
	
	ly4H = app.CreateLayout( "Linear", "Horizontal" );
	ly4.AddChild(ly4H);
	rev2 = app.CreateButton( "reveal 2",0.3, 0.06 );
	rev2.SetMargins(0,0,5,0,"px");
  rev2.SetOnTouch( rev2_OnTouch );	
  ly4H.AddChild( rev2 );
  
  nxt2 = app.CreateButton( "next",0.3, 0.06 );
  nxt2.SetOnTouch( nxt2_OnTouch );	
  ly4H.AddChild(nxt2);

// final layer
ly5 = app.CreateLayout( "Linear", "VCenter,FillXY" );
  
	ly5.SetBackground("Img/cd1.jpg" );
	ly5.SetVisibility( "Hide" );
	
	ly5H = app.CreateLayout( "Linear", "Horizontal" );
	ly5.AddChild(ly5H);
	rev3 = app.CreateButton( "reveal",0.3, 0.06 );
	rev3.SetMargins(0,0,5,0,"px");
  rev3.SetOnTouch( rev3_OnTouch );	
  ly5H.AddChild( rev3 );
  
  exit = app.CreateButton( "Exit",0.3, 0.06 );
  exit.SetOnTouch( exit_OnTouch );	
  ly5H.AddChild( exit );


  app.AddLayout(cover);
	app.AddLayout( main );
	app.AddLayout(ly );
	app.AddLayout(ly1);
	app.AddLayout(ly2);
	app.AddLayout( ly3 );
	app.AddLayout( ly4 );
	app.AddLayout( ly5 );
}
function about_OnTouch()
{
	ly.Animate( "SlideFromRight" );
}

function start_OnTouch()
{
	ly.Animate( "SlideFromRight" );
}


function nxt_OnTouch()
{
	ly.Animate( "SlideFromRight" );
}

function bck_OnTouch()
{
	ly1.Animate( "SlideFromRight" );
}

function bck1_OnTouch()
{
	ly2.Animate( "SlideFromRight" );
}

function bck2_OnTouch()

{
	ly3.Animate( "SlideFromRight" );
}
// appended  2*2
function nxt1_OnTouch()
{
	ly4.Animate( "SlideFromRight" );
}

function nxt2_OnTouch()
{
	ly5.Animate( "SlideFromRight" );
}

// qn1 results
function rev1_OnTouch()
{
  app.ShowPopup("This is how you answered.");
  qn1 = txtarea.GetText();
  intro1 = "On question 1 your answers were: ("
  concl1 = ")\nThese will define your priorities in your life basing on how you ranked them.\nCow Signifies CAREER \nTiger Signifies PRIDE \nSheep Signifies LOVE \nHorse Signifies FAMILY \n Pig Signifies MONEY"
  write_to = app.WriteFile("/sdcard/mind.txt",intro1+qn1+concl1)
	fileContents = app.ReadFile("/sdcard/mind.txt");
	app.Alert( fileContents );

}


// qn2 results
function rev2_OnTouch()
{
  //app.ShowPopup("This is how you answered.");
  qn2a = t2.GetText();
  qn2b = t3.GetText();
  qn2c = t4.GetText();
  qn2d = t5.GetText();
  qn2e = t6.GetText();
  
  q2a = "On question 2, Your description of DOG implies your own personality  ("
  q2b = "). \n\nYour description of CAT implies the personality of your partner ("
  q2c = ").\n\nYour description of RAT implies the personality of your enemies  ("
  q2d = "). \n\nYour description of COFFEE is how you interpret sex  ("
  q2e = "). \n\nYour description of the SEA implies your own life ("
  concl2 = ")\n\nHmm Funny isn't it."
  write_to = app.WriteFile("/sdcard/mind.txt",q2a+qn2a+q2b+qn2b+q2c+qn2c+q2d+qn2d+q2e+qn2e+concl2)
	fileContents = app.ReadFile("/sdcard/mind.txt");
	app.Alert( fileContents );

}

//last qn results 
function rev3_OnTouch()
{
  //app.ShowPopup("This is how you answered.");
  qn3a = tt2.GetText();
  qn3b = tt3.GetText();
  qn3c = tt4.GetText();
  qn3d = tt5.GetText();
  qn3e = tt6.GetText();
  
  q3a = " Finally, here comes the interesting part. \nThis is what each colour stands for:\nYELLOW: Someone you will never forget ("
  q3b = "). \n\nORANGE: Someone you consider your true friend ("
  q3c = ").\n\nRed: Someone that you really love  ("
  q3d = "). \n\nWhite: Your twin soul  ("
  q3e = "). \n\nGreen: Someone that you will remember for the rest of your life ("
  concl2 = ")\n\n\n\t\t\t       \t   Thank you\n Courtesy of ςimenya ʝօռȶɦǟռ.ε."
  write_to = app.WriteFile("/sdcard/mind.txt",q3a+qn3a+q3b+qn3b+q3c+qn3c+q3d+qn3d+q3e+qn3e+concl2)
	fileContents = app.ReadFile("/sdcard/mind.txt");
	app.Alert( fileContents );

}

function exit_OnTouch()
{
  app.Quit("                 Exiting App")
}